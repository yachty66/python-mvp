# python_mvp

Python package template with minimal setup and instructions on how to publish the package to PyPI and increase its visibility.

1. click the "Use this template" button at https://github.com/yachty66/python-mvp and create a new repository

2. name the folder inside `src` the same as the repository name / you want your python package to be named

3. populate the folders content with your code and before publishing run `pip install -e .` to test the functionality locally. With this package as an exampple you can do 

```python
python_mvp.main()
```

which will print "Hello World" to the console.

4. 